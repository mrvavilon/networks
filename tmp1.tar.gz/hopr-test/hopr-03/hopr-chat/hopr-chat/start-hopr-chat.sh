#!/bin/bash

cd -- "$(dirname "$0")"
node index.js -p switzerland 2>log.txt