import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AbstractCommand } from './abstractCommand';
export declare class Info extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    execute(): Promise<string>;
}
