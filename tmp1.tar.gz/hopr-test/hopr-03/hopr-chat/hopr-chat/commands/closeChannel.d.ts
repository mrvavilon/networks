import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import type { AutoCompleteResult } from './abstractCommand';
import { AbstractCommand } from './abstractCommand';
export default class CloseChannel extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    execute(query?: string): Promise<string | void>;
    autocomplete(query?: string, line?: string): Promise<AutoCompleteResult>;
}
