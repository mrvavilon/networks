import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AbstractCommand, AutoCompleteResult } from './abstractCommand';
export default class Withdraw extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    private arguments;
    constructor(node: Hopr<HoprCoreConnector>);
    /**
     * Will throw if any of the arguments are incorrect.
     */
    private checkArgs;
    name(): string;
    help(): string;
    autocomplete(query?: string): Promise<AutoCompleteResult>;
    /**
     * Withdraws native or hopr balance.
     * @notice triggered by the CLI
     */
    execute(query?: string): Promise<string>;
}
