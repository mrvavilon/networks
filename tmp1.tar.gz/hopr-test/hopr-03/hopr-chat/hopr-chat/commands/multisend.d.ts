/// <reference types="node" />
import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { SendMessageBase } from './sendMessage';
import readline from 'readline';
import { GlobalState, AutoCompleteResult, CommandResponse } from './abstractCommand';
export declare class MultiSendMessage extends SendMessageBase {
    node: Hopr<HoprCoreConnector>;
    rl: readline.Interface;
    constructor(node: Hopr<HoprCoreConnector>, rl: readline.Interface);
    name(): string;
    help(): string;
    private checkArgs;
    private repl;
    execute(query: string, state: GlobalState): Promise<CommandResponse>;
    autocomplete(query: string, line: string, state: GlobalState): Promise<AutoCompleteResult>;
}
