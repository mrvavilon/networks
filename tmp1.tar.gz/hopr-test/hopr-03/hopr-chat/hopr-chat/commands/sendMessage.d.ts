/// <reference types="node" />
import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import type { AutoCompleteResult, CommandResponse } from './abstractCommand';
import type PeerId from 'peer-id';
import readline from 'readline';
import { AbstractCommand, GlobalState } from './abstractCommand';
export declare abstract class SendMessageBase extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    private insertMyAddress;
    protected sendMessage(state: GlobalState, recipient: PeerId, rawMessage: string, getIntermediateNodes?: () => Promise<PeerId[]>): Promise<string | void>;
    autocomplete(query: string | undefined, line: string | undefined, state: GlobalState): Promise<AutoCompleteResult>;
}
export declare class SendMessage extends SendMessageBase {
    execute(query: string, state: GlobalState): Promise<CommandResponse>;
}
export declare class SendMessageFancy extends SendMessageBase {
    node: Hopr<HoprCoreConnector>;
    rl: readline.Interface;
    constructor(node: Hopr<HoprCoreConnector>, rl: readline.Interface);
    /**
     * Encapsulates the functionality that is executed once the user decides to send a message.
     * @param query peerId string to send message to
     */
    execute(query: string, state: GlobalState): Promise<string | void>;
    selectIntermediateNodes(rl: readline.Interface, destination: PeerId): Promise<PeerId[]>;
}
