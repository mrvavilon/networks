import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AbstractCommand } from './abstractCommand';
export default class PrintAddress extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    /**
     * Prints the name of the network we are using and the
     * identity that we have on that chain.
     * @notice triggered by the CLI
     */
    execute(query: string): Promise<string>;
}
