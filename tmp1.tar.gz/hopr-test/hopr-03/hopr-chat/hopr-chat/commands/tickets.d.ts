import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AbstractCommand } from './abstractCommand';
export default class Tickets extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    execute(): Promise<string | void>;
}
