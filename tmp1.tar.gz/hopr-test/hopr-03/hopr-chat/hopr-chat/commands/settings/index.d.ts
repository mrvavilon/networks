import { AbstractCommand, GlobalState, AutoCompleteResult } from '../abstractCommand';
export default class Settings extends AbstractCommand {
    private settings;
    private paddingLength;
    constructor();
    name(): string;
    help(): string;
    private get settingsKeys();
    execute(query: string, state: GlobalState): Promise<string | void>;
    autocomplete(query: string, line: string): Promise<AutoCompleteResult>;
}
