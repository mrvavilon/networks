import type PeerId from 'peer-id';
import { AbstractCommand, AutoCompleteResult, GlobalState } from '../abstractCommand';
export declare const options: ReadonlyArray<GlobalState['routing']>;
/**
 * Convert a query to a routing path
 * @param routing
 * @returns a promise that resolves into an array for peerIds
 */
export declare function queryToPeerIds(query: string): Promise<PeerId[]>;
/**
 * Looks into `state.routing` and parses the specified peerIds
 * @param routing
 * @returns a promise that resolves into an array for peerIds
 */
export declare function routingPathToPeerIds(path: string): Promise<PeerId[]>;
export declare function getRouting(state: GlobalState): string;
export declare class Routing extends AbstractCommand {
    name(): string;
    help(): string;
    execute(query: string, state: GlobalState): Promise<string | void>;
    autocomplete(query: string, line: string): Promise<AutoCompleteResult>;
}
