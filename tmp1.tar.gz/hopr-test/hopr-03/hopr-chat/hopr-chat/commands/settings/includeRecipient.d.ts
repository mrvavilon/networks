import { AbstractCommand, AutoCompleteResult, GlobalState } from '../abstractCommand';
export declare class IncludeRecipient extends AbstractCommand {
    private readonly options;
    name(): string;
    help(): string;
    execute(query: string, state: GlobalState): Promise<string | void>;
    autocomplete(query: string, line: string): Promise<AutoCompleteResult>;
}
