/// <reference types="node" />
import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type { Types } from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import type PeerId from 'peer-id';
import BN from 'bn.js';
import readline from 'readline';
import { AbstractCommand, AutoCompleteResult } from './abstractCommand';
export declare abstract class OpenChannelBase extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    protected validateAmountToFund(amountToFund: BN): Promise<void>;
    /**
     * Open's a payment channel
     *
     * @param counterParty the counter party's peerId
     * @param amountToFund the amount to fund in HOPR(wei)
     */
    protected openChannel(counterParty: PeerId, amountToFund: BN): Promise<{
        channelId: Types.Hash;
    }>;
    autocomplete(query?: string, line?: string): Promise<AutoCompleteResult>;
}
export declare class OpenChannel extends OpenChannelBase {
    /**
     * Encapsulates the functionality that is executed once the user decides to open a payment channel
     * with another party.
     * @param query peerId string to send message to
     */
    execute(query: string): Promise<string>;
}
export declare class OpenChannelFancy extends OpenChannelBase {
    node: Hopr<HoprCoreConnector>;
    rl: readline.Interface;
    constructor(node: Hopr<HoprCoreConnector>, rl: readline.Interface);
    private selectFundAmount;
    /**
     * Encapsulates the functionality that is executed once the user decides to open a payment channel
     * with another party.
     * @param query peerId string to send message to
     */
    execute(query?: string): Promise<string>;
}
