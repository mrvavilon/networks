import { AbstractCommand } from './abstractCommand';
export default class ListConnectors extends AbstractCommand {
    name(): string;
    help(): string;
    /**
     * Check which connectors are present right now.
     * @notice triggered by the CLI
     */
    execute(): Promise<string>;
}
