import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AbstractCommand } from './abstractCommand';
export default class RedeemTickets extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    /**
     * @param query a ticket challange
     */
    execute(): Promise<string | void>;
}
