import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AbstractCommand } from './abstractCommand';
export default class StopNode extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    /**
     * Stops the node and kills the process in case it does not quit by itself.
     */
    execute(): Promise<string | void>;
}
