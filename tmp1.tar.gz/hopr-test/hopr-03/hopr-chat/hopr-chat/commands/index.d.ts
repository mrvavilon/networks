/// <reference types="node" />
import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AutoCompleteResult } from './abstractCommand';
import { AbstractCommand, CommandResponse } from './abstractCommand';
import readline from 'readline';
export declare class Commands {
    node: Hopr<HoprCoreConnector>;
    readonly commands: AbstractCommand[];
    private commandMap;
    private state;
    constructor(node: Hopr<HoprCoreConnector>, rl?: readline.Interface);
    setState(settings: any): void;
    allCommands(): string[];
    find(command: string): AbstractCommand | undefined;
    execute(message: string): Promise<CommandResponse>;
    autocomplete(message: string): Promise<AutoCompleteResult>;
}
