export declare const v1: string;
export declare const v2: string[];
export declare const BACKGROUND_COLOR = "ffffa0";
export declare function renderHoprLogo(): void;
