export declare const cli_options: string[][];
