/**
 * Alphabetical list of known connectors.
 */
export declare const knownConnectors: string[][];
