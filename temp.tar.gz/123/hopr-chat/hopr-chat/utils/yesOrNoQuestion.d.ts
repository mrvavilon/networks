/// <reference types="node" />
import type readline from 'readline';
export declare function yesOrNoQuestion(rl: readline.Interface, message: string): Promise<boolean>;
