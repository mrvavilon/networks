import type { Types } from '@hoprnet/hopr-core-connector-interface';
/**
 * Retrieves all signed tickets from the given acknowledged tickets.
 *
 * @param ackTickets
 * @returns a promise that resolves into an array of signed tickets
 */
export declare function toSignedTickets(ackTickets: Types.AcknowledgedTicket[]): Promise<Types.SignedTicket[]>;
/**
 * Derive various data from the given signed tickets.
 *
 * @param signedTickets
 * @returns the total amount of tokens in the tickets & more
 */
export declare function countSignedTickets(signedTickets: Types.SignedTicket[]): {
    tickets: {
        challange: string;
        amount: string;
    }[];
    total: string;
};
