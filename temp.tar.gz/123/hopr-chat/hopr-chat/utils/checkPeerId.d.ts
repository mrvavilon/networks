import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import type { GlobalState } from '../commands/abstractCommand';
import PeerId from 'peer-id';
/**
 * Takes a string, and checks whether it's an alias or a valid peerId,
 * then it generates a PeerId instance and returns it.
 *
 * @param peerIdString query that contains the peerId
 * @returns a 'PeerId' instance
 */
export declare function checkPeerIdInput(peerIdString: string, state?: GlobalState): Promise<PeerId>;
/**
 * Returns a list of peerIds and aliases.
 * Optionally, you may choose various options.
 *
 * @param node hopr node
 * @param state global state
 * @param ops.noBootstrapNodes do not return any bootstrap nodes
 * @param ops.returnAlias when available, return the peerIds's alias
 * @param ops.mustBeOnline only return online peerIds
 * @returns an array of peerIds / aliases
 */
export declare function getPeerIdsAndAliases(node: Hopr<HoprCoreConnector>, state: GlobalState, ops?: {
    noBootstrapNodes: boolean;
    returnAlias: boolean;
    mustBeOnline: boolean;
}): string[];
