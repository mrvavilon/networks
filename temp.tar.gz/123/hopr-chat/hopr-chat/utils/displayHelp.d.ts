import chalk from 'chalk';
export declare function displayHelp(): void;
export declare function getPaddingLength(items: string[], addExtraPadding?: boolean): number;
export declare const CHALK_COLORS: {
    boolean: chalk.Chalk;
    number: chalk.Chalk;
    success: chalk.Chalk;
    failure: chalk.Chalk;
    peerId: chalk.Chalk;
    hash: chalk.Chalk;
    highlight: chalk.Chalk;
};
export declare const CHALK_STRINGS: {
    yes: string;
    no: string;
};
export declare function styleValue(value: any, type?: keyof typeof CHALK_COLORS): string;
export declare function getOptions(options: {
    value: any;
    description?: string;
}[], style?: 'compact' | 'vertical'): string[];
