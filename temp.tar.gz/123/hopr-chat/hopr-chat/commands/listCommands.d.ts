import { AbstractCommand } from './abstractCommand';
export default class ListCommands extends AbstractCommand {
    private getCommands;
    constructor(getCommands: () => AbstractCommand[]);
    name(): string;
    help(): string;
    execute(): string;
}
