import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AbstractCommand } from './abstractCommand';
export default class ListOpenChannels extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    private generateOutput;
    /**
     * Lists all channels that we have with other nodes. Triggered from the CLI.
     */
    execute(): Promise<string | void>;
}
