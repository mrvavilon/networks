import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import { AbstractCommand, GlobalState, AutoCompleteResult } from './abstractCommand';
export declare class Alias extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    private parameters;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    execute(query: string, state: GlobalState): Promise<string>;
    autocomplete(query: string, line: string, state: GlobalState): Promise<AutoCompleteResult>;
}
