import { AbstractCommand } from './abstractCommand';
export default class Version extends AbstractCommand {
    private items;
    name(): string;
    help(): string;
    execute(): Promise<string>;
}
