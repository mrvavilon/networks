import type HoprCoreConnector from '@hoprnet/hopr-core-connector-interface';
import type Hopr from '@hoprnet/hopr-core';
import type { AutoCompleteResult } from './abstractCommand';
import { AbstractCommand, GlobalState } from './abstractCommand';
export default class Ping extends AbstractCommand {
    node: Hopr<HoprCoreConnector>;
    constructor(node: Hopr<HoprCoreConnector>);
    name(): string;
    help(): string;
    execute(query: string, state: GlobalState): Promise<string>;
    autocomplete(query: string | undefined, line: string | undefined, state: GlobalState): Promise<AutoCompleteResult>;
}
