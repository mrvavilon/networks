import type PeerId from 'peer-id';
export declare type AutoCompleteResult = [string[], string];
export declare const emptyAutoCompleteResult: (line: string) => AutoCompleteResult;
export declare type CommandResponse = string | void;
export declare type GlobalState = {
    aliases: Map<string, PeerId>;
    includeRecipient: boolean;
    routing: 'direct' | 'manual';
    routingPath: PeerId[];
};
export declare abstract class AbstractCommand {
    abstract name(): string;
    abstract help(): string;
    abstract execute(query: string, state: GlobalState): CommandResponse | Promise<CommandResponse>;
    autocomplete(query: string, line: string, state: GlobalState): Promise<AutoCompleteResult>;
    protected _autocompleteByFiltering(query: string, allResults: string[], line: string): AutoCompleteResult;
    protected usage(parameters: string[]): string;
    protected _assertUsage(query: string, parameters: string[], test?: RegExp): string[];
}
